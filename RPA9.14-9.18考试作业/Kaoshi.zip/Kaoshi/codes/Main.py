# coding=utf-8
# 编译日期：2020-09-18 11:10:05
# 版权所有：www.i-search.com.cn
import ubpa.init_input as iinput
from ubpa.base_util import StdOutHook, ExceptionHandler
import ubpa.iie as iie
import ubpa.iexcel as iexcel
import ubpa.icsv as icsv
import pandas as pd
import time
import pdb
from ubpa.ilog import ILog
from ubpa.base_img import set_img_res_path
import getopt
from sys import argv
import sys
import os

class Kaoshi:
     
    def __init__(self,**kwargs):
        self.__logger = ILog(__file__)
        self.path = set_img_res_path(__file__)
        self.robot_no = ''
        self.proc_no = ''
        self.job_no = ''
        self.input_arg = ''
        if('robot_no' in kwargs.keys()):
            self.robot_no = kwargs['robot_no']
        if('proc_no' in kwargs.keys()):
            self.proc_no = kwargs['proc_no']
        if('job_no' in kwargs.keys()):
            self.job_no = kwargs['job_no']
        ILog.JOB_NO, ILog.OLD_STDOUT = self.job_no, sys.stdout
        sys.stdout = StdOutHook(self.job_no, sys.stdout)
        ExceptionHandler.JOB_NO, ExceptionHandler.OLD_STDERR = self.job_no, sys.stderr
        sys.excepthook = ExceptionHandler.handle_exception
        if('input_arg' in kwargs.keys()):
            self.input_arg = kwargs['input_arg']
            if(len(self.input_arg) <= 0):
                self.input_arg = iinput.load_init(__file__)
            if self.input_arg is None:
                sys.exit(0)
      
    def GL_data(self):
        a_LuJing=None
        a00i=None
        a00_list=None
        DF_a001=None
        DF_values=None
        #读取Excel
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918104117418136,Title:读取Excel,Note:')
        DF_values=pd.read_excel(io='C:/Users/帅气可爱的小飞/Desktop/DataSource+24.xlsx')
        #读取整列
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918104823157159,Title:读取整列,Note:')
        a00_list=iexcel.read_col(path='C:/Users/帅气可爱的小飞/Desktop/DataSource+24.xlsx',cell='B1')
        #代码块
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918105230361171,Title:代码块,Note:')
        a00_list = a00_list[1:]
        # For循环
        self.__logger.dlogs(job_no=self.job_no, logmsg='Flow:GL_data,StepNodeTag:20200918105451864180,Title:For循环,Note:')
        for a00i in a00_list:
            #表格过滤
            self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918104231108144,Title:表格过滤,Note:')
            DF_a001=DF_values[(DF_values['产品名称']== a00i)]
            #代码块
            self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918110404822209,Title:代码块,Note:')
            a_LuJing = 'C:/Users/帅气可爱的小飞/Desktop/' + a00i + '.xlsx'
            # Try异常
            self.__logger.dlogs(job_no=self.job_no, logmsg='Flow:GL_data,StepNodeTag:20200918105728631193,Title:Try异常,Note:')
            try:
                #创建excel
                self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918105810405195,Title:创建excel,Note:')
                iexcel.create_excel(path='C:/Users/帅气可爱的小飞/Desktop',file_name=a00i)
            except Exception as e:
                pass
            finally:
                #导出excel
                self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:GL_data,StepNodeTag:20200918105928997201,Title:导出excel,Note:')
                icsv.write_excel(path=a_LuJing,df=DF_a001)
      
    def get_data_search01(self):
        df_01=None
        #拾取表格(web)
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:get_data_search01,StepNodeTag:2020091810133879155,Title:拾取表格(web),Note:')
        time.sleep(10)
        df_01=iie.get_ie_table(waitfor=10.000,selector=r'#boxTable',title=r'理财管理',continue_on_error='break')
        time.sleep(5)
        # Return返回
        self.__logger.dlogs(job_no=self.job_no, logmsg='Flow:get_data_search01,StepNodeTag:2020091810223544579,Title:Return返回,Note:')
        return df_01
      
    def login(self):
        password='typSVU'
        user='ceshi001'
        #网站
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:login,StepNodeTag:2020091809462913910,Title:网站,Note:')
        iie.open_url(ie_path='C:/Program Files (x86)/Internet Explorer/iexplore.exe',url='http://122.112.200.222:9080/login.action')
        #设置文本
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:login,StepNodeTag:2020091809470978312,Title:设置文本,Note:')
        iie.set_text(waitfor=10.000,text=user,selector=r'body > FORM:nth-of-type(1) > DIV:nth-of-type(1) > UL:nth-of-type(1) > LI:nth-of-type(1) > INPUT:nth-of-type(1)',url=r'http://122.112.200.222:9080/login.action')
        #设置文本
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:login,StepNodeTag:2020091809481538317,Title:设置文本,Note:')
        iie.set_text(waitfor=10.000,text=password,selector=r'body > FORM:nth-of-type(1) > DIV:nth-of-type(1) > UL:nth-of-type(1) > LI:nth-of-type(2) > INPUT:nth-of-type(1)',url=r'http://122.112.200.222:9080/login.action')
        #鼠标点击
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:login,StepNodeTag:2020091809491701323,Title:鼠标点击,Note:')
        iie.do_click_pos(waitfor=10.000,run_mode='unctrl',button='left',curson='center',continue_on_error='break',win_title=r'双录系统-录音、录像、录屏 - Internet Explorer',selector=r'body > FORM:nth-of-type(1) > DIV:nth-of-type(1) > UL:nth-of-type(1) > LI:nth-of-type(2) > INPUT:nth-of-type(2)',url=r'http://122.112.200.222:9080/login.action')
        #鼠标点击
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:login,StepNodeTag:2020091809522040229,Title:鼠标点击,Note:')
        iie.do_click_pos(waitfor=10.000,run_mode='unctrl',button='left',curson='center',continue_on_error='break',win_title=r'双录系统-录音、录像、录屏 - Internet Explorer',selector=r'#popup_ok',url=r'http://122.112.200.222:9080/login.action')
      
    def search_01(self):
        search_value='i-Search-01'
        #鼠标点击
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:search_01,StepNodeTag:2020091809555872736,Title:鼠标点击,Note:')
        iie.do_click_pos(waitfor=10.000,run_mode='unctrl',button='left',curson='center',continue_on_error='break',win_title=r'双录系统-录音、录像、录屏 - Internet Explorer',selector=r'#frame-nav > UL:nth-of-type(1) > LI:nth-of-type(1) > A:nth-of-type(1)',url=r'http://122.112.200.222:9080/login.action')
        #鼠标点击
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:search_01,StepNodeTag:2020091809562364738,Title:鼠标点击,Note:')
        iie.do_click_pos(waitfor=10.000,run_mode='unctrl',button='left',curson='center',continue_on_error='break',win_title=r'双录系统-录音、录像、录屏 - Internet Explorer',selector=r'#MenuContext > TABLE:nth-of-type(1) > TBODY:nth-of-type(1) > TR:nth-of-type(1) > TD:nth-of-type(2) > LI:nth-of-type(5) > A:nth-of-type(1)',url=r'http://122.112.200.222:9080/login.action')
        #设置文本
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:search_01,StepNodeTag:2020091809570779740,Title:设置文本,Note:')
        iie.set_text(waitfor=10.000,text=search_value,selector=r'body > DIV:nth-of-type(1) > FORM:nth-of-type(1) > DIV:nth-of-type(2) > DIV:nth-of-type(1) > UL:nth-of-type(1) > LI:nth-of-type(1) > INPUT:nth-of-type(1)',title=r'理财管理')
        #鼠标点击
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:search_01,StepNodeTag:2020091809592910746,Title:鼠标点击,Note:')
        time.sleep(5)
        iie.do_click_pos(waitfor=10.000,run_mode='unctrl',button='left',curson='center',continue_on_error='break',win_title=r'双录系统-录音、录像、录屏 - Internet Explorer',selector=r'#ListForm > DIV:nth-of-type(2) > DIV:nth-of-type(1) > UL:nth-of-type(1) > LI:nth-of-type(4) > BUTTON:nth-of-type(1)',title=r'理财管理')
        time.sleep(5)
      
    def write_data_search01(self,pv_1=None):
        filename='DataSource+24'
        # Try异常
        self.__logger.dlogs(job_no=self.job_no, logmsg='Flow:write_data_search01,StepNodeTag:2020091810184485964,Title:Try异常,Note:')
        try:
            #创建excel
            self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:write_data_search01,StepNodeTag:2020091810190604167,Title:创建excel,Note:')
            iexcel.create_excel(path='C:/Users/帅气可爱的小飞/Desktop',file_name=filename)
        except Exception as e:
            pass
        finally:
            #导出excel
            self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:write_data_search01,StepNodeTag:2020091810210935274,Title:导出excel,Note:')
            icsv.write_excel(path='C:/Users/帅气可爱的小飞/Desktop/DataSource+24.xlsx',df=pv_1)
      
    def Main(self):
        #子流程
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:Main,StepNodeTag:2020091809533391232,Title:子流程,Note:')
        tvar20200918095333912321=self.login()
        #子流程
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:Main,StepNodeTag:2020091809594936148,Title:子流程,Note:')
        tvar20200918095949361481=self.search_01()
        #子流程
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:Main,StepNodeTag:2020091810225717882,Title:子流程,Note:')
        tvar20200918102257178821=self.get_data_search01()
        #子流程
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:Main,StepNodeTag:2020091810230937384,Title:子流程,Note:')
        tvar20200918102309373841=self.write_data_search01(pv_1=tvar20200918102257178821)
        #子流程
        self.__logger.dlogs(job_no=self.job_no,logmsg='Flow:Main,StepNodeTag:20200918110948108215,Title:子流程,Note:')
        tvar202009181109481082151=self.GL_data()
 
if __name__ == '__main__':
    ILog.begin_init()
    robot_no = ''
    proc_no = ''
    job_no = ''
    input_arg = ''
    try:
        argv = sys.argv[1:]
        opts, args = getopt.getopt(argv,"hr:p:j:i:",["robot = ","proc = ","job = ","input = "])
    except getopt.GetoptError:
        print ('robot.py -r <robot> -p <proc> -j <job>')
    for opt, arg in opts:
        if opt == '-h':
            print ('robot.py -r <robot> -p <proc> -j <job>')
        elif opt in ("-r", "--robot"):
            robot_no = arg
        elif opt in ("-p", "--proc"):
            proc_no = arg
        elif opt in ("-j", "--job"):
            job_no = arg
        elif opt in ("-i", "--input"):
            input_arg = arg
    pro = Kaoshi(robot_no=robot_no,proc_no=proc_no,job_no=job_no,input_arg=input_arg)
    pro.Main()
